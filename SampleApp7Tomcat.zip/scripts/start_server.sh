#!/bin/bash
systemctl start tomcat.service

