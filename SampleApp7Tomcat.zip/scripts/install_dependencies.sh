#!/bin/bash
yum install -y tomcat

