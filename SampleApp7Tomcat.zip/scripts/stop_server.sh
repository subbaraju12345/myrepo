#!/bin/bash
systemctl stop tomcat.service
